package com.streetfinest.dadhealthtracker;

import android.app.Activity;
import android.app.AlertDialog;
import android.os.Bundle;
import android.graphics.Color;
import android.graphics.Typeface;
import android.net.Uri;
import android.view.Gravity;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.content.Context;
import android.content.Intent;
import android.widget.*;
import org.json.JSONObject;
import java.io.OutputStream;
import java.text.DecimalFormat;
import java.time.LocalDate;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.List;

public class MainActivity extends Activity {
    private HealthDbHelper db;
    private final int TEAL = Color.rgb(15, 118, 110);
    private final int DARK = Color.rgb(17, 24, 39);
    private final int MUTED = Color.rgb(107, 114, 128);
    private final int BG = Color.rgb(246, 247, 246);
    private final DecimalFormat oneDp = new DecimalFormat("0.0");

    private static final int REQUEST_SAVE_FILE = 4401;
    private String pendingFileContent = "";
    private String pendingMimeType = "text/plain";
    private String pendingFilename = "dad_health_export.txt";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        db = new HealthDbHelper(this);
        showHome();
    }

    private TextView tv(String text, int sp, int color, int style) {
        TextView v = new TextView(this);
        v.setText(text);
        v.setTextSize(sp);
        v.setTextColor(color);
        v.setTypeface(Typeface.DEFAULT, style);
        v.setPadding(dp(4), dp(4), dp(4), dp(4));
        return v;
    }

    private TextView label(String text) {
        return tv(text, 14, DARK, Typeface.BOLD);
    }

    private EditText input(String hint) {
        EditText e = new EditText(this);
        e.setHint(hint);
        e.setTextSize(18);
        e.setSingleLine(false);
        e.setPadding(dp(12), dp(10), dp(12), dp(10));
        e.setBackgroundColor(Color.WHITE);
        e.setLayoutParams(new LinearLayout.LayoutParams(-1, -2));
        return e;
    }

    private Button button(String text) {
        Button b = new Button(this);
        b.setText(text);
        b.setTextSize(16);
        b.setAllCaps(false);
        b.setTextColor(Color.WHITE);
        b.setBackgroundColor(TEAL);
        b.setPadding(dp(12), dp(10), dp(12), dp(10));
        return b;
    }

    private Button lightButton(String text) {
        Button b = new Button(this);
        b.setText(text);
        b.setTextSize(15);
        b.setAllCaps(false);
        b.setTextColor(TEAL);
        b.setBackgroundColor(Color.WHITE);
        b.setPadding(dp(12), dp(10), dp(12), dp(10));
        return b;
    }

    private LinearLayout base(String title) {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(BG);

        TextView header = tv(title, 24, Color.WHITE, Typeface.BOLD);
        header.setBackgroundColor(TEAL);
        header.setPadding(dp(18), dp(22), dp(18), dp(18));
        root.addView(header, new LinearLayout.LayoutParams(-1, -2));

        return root;
    }

    private ScrollView contentArea(LinearLayout root) {
        ScrollView scroll = new ScrollView(this);
        LinearLayout content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(dp(14), dp(14), dp(14), dp(14));
        scroll.addView(content);
        root.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1));
        scroll.setTag(content);
        return scroll;
    }

    private void addNav(LinearLayout root, String active) {
        LinearLayout nav = new LinearLayout(this);
        nav.setOrientation(LinearLayout.HORIZONTAL);
        nav.setGravity(Gravity.CENTER);
        nav.setPadding(dp(6), dp(6), dp(6), dp(6));
        nav.setBackgroundColor(Color.WHITE);

        String[] names = {"Home", "Add", "History", "Reports", "Backup"};
        for (String n : names) {
            Button b = new Button(this);
            b.setText(n);
            b.setTextSize(12);
            b.setAllCaps(false);
            b.setTextColor(n.equals(active) ? Color.WHITE : TEAL);
            b.setBackgroundColor(n.equals(active) ? TEAL : Color.WHITE);
            b.setOnClickListener(v -> {
                if (n.equals("Home")) showHome();
                if (n.equals("Add")) showAdd();
                if (n.equals("History")) showHistory();
                if (n.equals("Reports")) showReports();
                if (n.equals("Backup")) showBackup();
            });
            nav.addView(b, new LinearLayout.LayoutParams(0, dp(52), 1));
        }
        root.addView(nav, new LinearLayout.LayoutParams(-1, -2));
    }

    private LinearLayout card(LinearLayout parent) {
        LinearLayout c = new LinearLayout(this);
        c.setOrientation(LinearLayout.VERTICAL);
        c.setPadding(dp(14), dp(12), dp(14), dp(12));
        c.setBackgroundColor(Color.WHITE);
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, -2);
        p.setMargins(0, 0, 0, dp(10));
        parent.addView(c, p);
        return c;
    }

    private void showHome() {
        LinearLayout root = base("Dad Health Tracker");
        LinearLayout content = (LinearLayout) contentArea(root).getTag();

        List<HealthDbHelper.Reading> readings = db.getAllReadings();
        HealthDbHelper.Reading latest = readings.isEmpty() ? null : readings.get(0);

        Button add = button("+ Add New Reading");
        add.setOnClickListener(v -> showAdd());
        content.addView(add, new LinearLayout.LayoutParams(-1, dp(58)));

        LinearLayout c1 = card(content);
        c1.addView(tv("Latest Sugar", 14, MUTED, Typeface.NORMAL));
        c1.addView(tv(latest != null && latest.sugar != null ? oneDp.format(latest.sugar) + " mmol/L" : "—", 28, DARK, Typeface.BOLD));

        LinearLayout c2 = card(content);
        c2.addView(tv("Latest Blood Pressure", 14, MUTED, Typeface.NORMAL));
        c2.addView(tv(latest != null ? bpText(latest) : "—", 28, DARK, Typeface.BOLD));

        LinearLayout c3 = card(content);
        c3.addView(tv("7-Day Summary", 18, DARK, Typeface.BOLD));
        List<HealthDbHelper.Reading> week = db.getReadingsSince(LocalDate.now().minusDays(7).toString());
        c3.addView(tv("Average sugar: " + avgSugar(week), 16, DARK, Typeface.NORMAL));
        c3.addView(tv("Average BP: " + avgBp(week), 16, DARK, Typeface.NORMAL));
        c3.addView(tv("Readings: " + week.size(), 16, DARK, Typeface.NORMAL));

        LinearLayout c4 = card(content);
        c4.addView(tv("Latest Entry", 18, DARK, Typeface.BOLD));
        if (latest == null) {
            c4.addView(tv("No readings yet. Tap Add New Reading.", 16, MUTED, Typeface.NORMAL));
        } else {
            c4.addView(tv(latest.date + " at " + latest.time, 16, DARK, Typeface.BOLD));
            c4.addView(tv(latest.context, 14, MUTED, Typeface.NORMAL));
            c4.addView(tv("Sugar: " + value(latest.sugar) + " | BP: " + bpText(latest) + " | Pulse: " + value(latest.pulse), 15, DARK, Typeface.NORMAL));
            if (latest.notes != null && !latest.notes.trim().isEmpty()) c4.addView(tv(latest.notes, 14, MUTED, Typeface.NORMAL));
        }

        addNav(root, "Home");
        setContentView(root);
    }

    private void showAdd() {
        LinearLayout root = base("Add Reading");
        LinearLayout content = (LinearLayout) contentArea(root).getTag();

        EditText date = input("YYYY-MM-DD");
        date.setText(LocalDate.now().toString());

        EditText time = input("HH:mm");
        time.setText(LocalTime.now().format(DateTimeFormatter.ofPattern("HH:mm")));

        Spinner spinner = new Spinner(this);
        String[] contexts = {"Before breakfast", "After breakfast", "Before lunch", "After lunch", "Before dinner", "After dinner", "Bedtime", "Random check"};
        spinner.setAdapter(new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, contexts));

        EditText sugar = input("Example: 8.7");
        EditText sys = input("BP top number e.g. 135");
        EditText dia = input("BP bottom number e.g. 84");
        EditText pulse = input("Optional pulse");
        EditText notes = input("Food, medicine, symptoms, or notes");

        content.addView(label("Date")); content.addView(date);
        content.addView(label("Time")); content.addView(time);
        content.addView(label("Reading Time")); content.addView(spinner);
        content.addView(label("Blood Sugar")); content.addView(sugar);
        content.addView(label("BP Top Number / Systolic")); content.addView(sys);
        content.addView(label("BP Bottom Number / Diastolic")); content.addView(dia);
        content.addView(label("Pulse")); content.addView(pulse);
        content.addView(label("Notes")); content.addView(notes);

        Button save = button("Save Reading");
        save.setOnClickListener(v -> {
            hideKeyboard(v);

            String d = date.getText().toString().trim();
            String t = time.getText().toString().trim();
            String ctx = spinner.getSelectedItem().toString();
            Double sugarVal = parseDouble(sugar.getText().toString());
            Integer sysVal = parseInt(sys.getText().toString());
            Integer diaVal = parseInt(dia.getText().toString());
            Integer pulseVal = parseInt(pulse.getText().toString());
            String noteVal = notes.getText().toString().trim();

            if (d.isEmpty() || t.isEmpty()) {
                toast("Date and time are required.");
                return;
            }
            if (sugarVal == null && sysVal == null && diaVal == null) {
                toast("Enter sugar or blood pressure.");
                return;
            }
            if ((sysVal == null) != (diaVal == null)) {
                toast("Enter both BP top and bottom numbers.");
                return;
            }

            db.insertReading(d, t, ctx, sugarVal, sysVal, diaVal, pulseVal, noteVal);
            toast("Reading saved.");
            showHome();
        });

        LinearLayout.LayoutParams saveParams = new LinearLayout.LayoutParams(-1, dp(60));
        saveParams.setMargins(0, dp(14), 0, dp(10));
        content.addView(save, saveParams);

        addNav(root, "Add");
        setContentView(root);
    }

    private void showHistory() {
        LinearLayout root = base("History");
        LinearLayout content = (LinearLayout) contentArea(root).getTag();
        List<HealthDbHelper.Reading> readings = db.getAllReadings();

        content.addView(tv(readings.size() + " readings saved", 16, MUTED, Typeface.NORMAL));

        if (readings.isEmpty()) {
            LinearLayout c = card(content);
            c.addView(tv("No records yet", 20, DARK, Typeface.BOLD));
            c.addView(tv("Saved readings will appear here.", 15, MUTED, Typeface.NORMAL));
        }

        for (HealthDbHelper.Reading r : readings) {
            LinearLayout c = card(content);
            c.addView(tv(r.date + " at " + r.time, 17, DARK, Typeface.BOLD));
            c.addView(tv(r.context, 14, MUTED, Typeface.NORMAL));
            c.addView(tv("Sugar: " + value(r.sugar), 15, DARK, Typeface.NORMAL));
            c.addView(tv("BP: " + bpText(r), 15, DARK, Typeface.NORMAL));
            c.addView(tv("Pulse: " + value(r.pulse), 15, DARK, Typeface.NORMAL));
            if (r.notes != null && !r.notes.trim().isEmpty()) c.addView(tv("Notes: " + r.notes, 14, MUTED, Typeface.NORMAL));

            Button del = lightButton("Delete");
            del.setOnClickListener(v -> new AlertDialog.Builder(this)
                    .setTitle("Delete reading?")
                    .setMessage("This removes the selected record from this phone.")
                    .setPositiveButton("Delete", (dialog, which) -> {
                        db.deleteReading(r.id);
                        showHistory();
                    })
                    .setNegativeButton("Cancel", null)
                    .show());
            c.addView(del);
        }

        addNav(root, "History");
        setContentView(root);
    }

    private void showReports() {
        LinearLayout root = base("Reports");
        LinearLayout content = (LinearLayout) contentArea(root).getTag();

        addReportCard(content, "Weekly Report", 7);
        addReportCard(content, "Monthly Report", 30);

        LinearLayout info = card(content);
        info.addView(tv("Export flow improved", 18, DARK, Typeface.BOLD));
        info.addView(tv("Preview first, then save. The phone will ask where to save the CSV file, so you can choose Downloads, Documents, or Drive.", 15, MUTED, Typeface.NORMAL));

        addNav(root, "Reports");
        setContentView(root);
    }

    private void addReportCard(LinearLayout content, String title, int days) {
        List<HealthDbHelper.Reading> rows = db.getReadingsSince(LocalDate.now().minusDays(days).toString());
        LinearLayout c = card(content);
        c.addView(tv(title, 20, DARK, Typeface.BOLD));
        c.addView(tv("Readings: " + rows.size(), 15, DARK, Typeface.NORMAL));
        c.addView(tv("Average sugar: " + avgSugar(rows), 15, DARK, Typeface.NORMAL));
        c.addView(tv("Average BP: " + avgBp(rows), 15, DARK, Typeface.NORMAL));

        Button preview = button("Preview " + days + "-Day Report");
        preview.setOnClickListener(v -> showReportPreview(title, days));
        c.addView(preview, new LinearLayout.LayoutParams(-1, dp(56)));
    }

    private void showReportPreview(String title, int days) {
        LinearLayout root = base(title + " Preview");
        LinearLayout content = (LinearLayout) contentArea(root).getTag();

        List<HealthDbHelper.Reading> rows = db.getReadingsSince(LocalDate.now().minusDays(days).toString());

        LinearLayout summary = card(content);
        summary.addView(tv("Summary", 20, DARK, Typeface.BOLD));
        summary.addView(tv("Period: Last " + days + " days", 15, DARK, Typeface.NORMAL));
        summary.addView(tv("Readings: " + rows.size(), 15, DARK, Typeface.NORMAL));
        summary.addView(tv("Average sugar: " + avgSugar(rows), 15, DARK, Typeface.NORMAL));
        summary.addView(tv("Average BP: " + avgBp(rows), 15, DARK, Typeface.NORMAL));

        Button saveCsv = button("Save CSV File");
        saveCsv.setOnClickListener(v -> {
            String filename = "dad_health_" + days + "_day_report_" + LocalDate.now() + ".csv";
            saveFileWithPicker(buildCsv(rows), "text/csv", filename);
        });
        summary.addView(saveCsv, new LinearLayout.LayoutParams(-1, dp(56)));

        TextView previewTitle = tv("Readings Preview", 20, DARK, Typeface.BOLD);
        content.addView(previewTitle);

        if (rows.isEmpty()) {
            LinearLayout empty = card(content);
            empty.addView(tv("No readings in this period.", 16, MUTED, Typeface.NORMAL));
        }

        for (HealthDbHelper.Reading r : rows) {
            LinearLayout c = card(content);
            c.addView(tv(r.date + " at " + r.time, 17, DARK, Typeface.BOLD));
            c.addView(tv(r.context, 14, MUTED, Typeface.NORMAL));
            c.addView(tv("Sugar: " + value(r.sugar), 15, DARK, Typeface.NORMAL));
            c.addView(tv("BP: " + bpText(r), 15, DARK, Typeface.NORMAL));
            c.addView(tv("Pulse: " + value(r.pulse), 15, DARK, Typeface.NORMAL));
            if (r.notes != null && !r.notes.trim().isEmpty()) c.addView(tv("Notes: " + r.notes, 14, MUTED, Typeface.NORMAL));
        }

        addNav(root, "Reports");
        setContentView(root);
    }

    private void showBackup() {
        LinearLayout root = base("Backup");
        LinearLayout content = (LinearLayout) contentArea(root).getTag();

        LinearLayout c = card(content);
        c.addView(tv("Saved readings", 16, MUTED, Typeface.NORMAL));
        c.addView(tv(String.valueOf(db.getAllReadings().size()), 28, DARK, Typeface.BOLD));
        c.addView(tv("Create a backup before changing phones or deleting the app.", 14, MUTED, Typeface.NORMAL));

        Button backup = button("Save Backup File");
        backup.setOnClickListener(v -> exportBackup());
        c.addView(backup, new LinearLayout.LayoutParams(-1, dp(56)));

        LinearLayout c2 = card(content);
        c2.addView(tv("Restore backup", 18, DARK, Typeface.BOLD));
        c2.addView(tv("Restore will be added in the next version.", 15, MUTED, Typeface.NORMAL));

        addNav(root, "Backup");
        setContentView(root);
    }

    private String buildCsv(List<HealthDbHelper.Reading> rows) {
        StringBuilder sb = new StringBuilder();
        sb.append("Date,Time,Context,Blood Sugar,Systolic BP,Diastolic BP,Pulse,Notes\n");
        for (HealthDbHelper.Reading r : rows) {
            sb.append(csv(r.date)).append(",")
                    .append(csv(r.time)).append(",")
                    .append(csv(r.context)).append(",")
                    .append(csv(value(r.sugar))).append(",")
                    .append(csv(value(r.systolic))).append(",")
                    .append(csv(value(r.diastolic))).append(",")
                    .append(csv(value(r.pulse))).append(",")
                    .append(csv(r.notes)).append("\n");
        }
        return sb.toString();
    }

    private void exportBackup() {
        try {
            JSONObject root = new JSONObject();
            root.put("app", "Dad Health Tracker");
            root.put("backupDate", LocalDate.now().toString());
            root.put("version", 2);
            root.put("readings", db.toJsonArray());
            String filename = "dad_health_backup_" + LocalDate.now() + ".json";
            saveFileWithPicker(root.toString(2), "application/json", filename);
        } catch (Exception e) {
            toast("Backup failed: " + e.getMessage());
        }
    }

    private void saveFileWithPicker(String content, String mimeType, String filename) {
        pendingFileContent = content;
        pendingMimeType = mimeType;
        pendingFilename = filename;

        Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType(mimeType);
        intent.putExtra(Intent.EXTRA_TITLE, filename);
        startActivityForResult(intent, REQUEST_SAVE_FILE);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == REQUEST_SAVE_FILE) {
            if (resultCode == RESULT_OK && data != null && data.getData() != null) {
                Uri uri = data.getData();
                try {
                    OutputStream out = getContentResolver().openOutputStream(uri);
                    if (out == null) {
                        toast("Could not open selected file.");
                        return;
                    }
                    out.write(pendingFileContent.getBytes("UTF-8"));
                    out.close();
                    toast("Saved successfully.");
                } catch (Exception e) {
                    toast("Save failed: " + e.getMessage());
                }
            } else {
                toast("Save cancelled.");
            }
        }
        super.onActivityResult(requestCode, resultCode, data);
    }

    private String avgSugar(List<HealthDbHelper.Reading> rows) {
        double sum = 0; int count = 0;
        for (HealthDbHelper.Reading r : rows) {
            if (r.sugar != null) { sum += r.sugar; count++; }
        }
        return count == 0 ? "—" : oneDp.format(sum / count);
    }

    private String avgBp(List<HealthDbHelper.Reading> rows) {
        double sys = 0, dia = 0; int count = 0;
        for (HealthDbHelper.Reading r : rows) {
            if (r.systolic != null && r.diastolic != null) {
                sys += r.systolic; dia += r.diastolic; count++;
            }
        }
        return count == 0 ? "—" : Math.round(sys / count) + "/" + Math.round(dia / count);
    }

    private String bpText(HealthDbHelper.Reading r) {
        if (r == null || r.systolic == null || r.diastolic == null) return "—";
        return r.systolic + "/" + r.diastolic;
    }

    private String value(Object o) {
        return o == null ? "—" : String.valueOf(o);
    }

    private Double parseDouble(String s) {
        try {
            s = s.trim();
            if (s.isEmpty()) return null;
            return Double.parseDouble(s);
        } catch (Exception e) {
            return null;
        }
    }

    private Integer parseInt(String s) {
        try {
            s = s.trim();
            if (s.isEmpty()) return null;
            return Integer.parseInt(s);
        } catch (Exception e) {
            return null;
        }
    }

    private String csv(String s) {
        if (s == null) s = "";
        return "\"" + s.replace("\"", "\"\"") + "\"";
    }

    private void toast(String message) {
        Toast.makeText(this, message, Toast.LENGTH_LONG).show();
    }

    private int dp(int v) {
        return Math.round(v * getResources().getDisplayMetrics().density);
    }

    private void hideKeyboard(View v) {
        try {
            InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
            imm.hideSoftInputFromWindow(v.getWindowToken(), 0);
        } catch (Exception ignored) {}
    }
}
