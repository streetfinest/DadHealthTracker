# Changelog

## v0.2.0

Fixed:
- Export no longer saves silently inside hidden app-private folder.
- Reports now show preview before saving.
- CSV export opens Android save dialog so user chooses the location.

Still missing:
- Restore backup
- PDF export
- Share CSV after saving
