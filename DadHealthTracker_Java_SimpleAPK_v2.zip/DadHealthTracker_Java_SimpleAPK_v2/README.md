# Dad Health Tracker — Java Simple APK v2

This version improves export usability.

## New in v2

- Report preview before exporting
- CSV export uses Android's file picker
- User chooses where to save the file
- Backup export also uses Android's file picker
- No confusing hidden `/Android/data/...` save path

## Features

- Dashboard
- Add Reading
- History
- Weekly report preview
- Monthly report preview
- CSV export
- Backup JSON export
- Offline SQLite storage

## Next version

- Restore backup
- PDF export
- Share button
- Cleaner modern UI
