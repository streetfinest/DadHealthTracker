# Dad Health Tracker — Simple Java APK Version

This is a simpler Android APK project made to build cleanly in GitHub Actions without Android Studio.

## Why this version exists

The first Kotlin/Compose version was too heavy for cloud debugging. This version is pure Android Java with SQLite and no external dependencies.

## Features

- Dashboard
- Add Reading
- History
- Weekly/monthly CSV export
- Backup JSON export
- Offline SQLite storage
- No login
- No domain
- No Play Store needed

## How to build

Upload this ZIP to GitHub and use `.github/workflows/build-from-zip.yml`.

The output will be a debug APK artifact.
