package com.streetfinest.dadhealthtracker;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import org.json.JSONArray;
import org.json.JSONObject;
import java.util.ArrayList;
import java.util.List;

public class HealthDbHelper extends SQLiteOpenHelper {
    private static final String DB_NAME = "dad_health_tracker.db";
    private static final int DB_VERSION = 1;

    public static class Reading {
        public long id;
        public String date;
        public String time;
        public String context;
        public Double sugar;
        public Integer systolic;
        public Integer diastolic;
        public Integer pulse;
        public String notes;
        public long createdAt;
    }

    public HealthDbHelper(Context context) {
        super(context, DB_NAME, null, DB_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(
            "CREATE TABLE readings (" +
            "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
            "date TEXT NOT NULL, " +
            "time TEXT NOT NULL, " +
            "context TEXT NOT NULL, " +
            "sugar REAL, " +
            "systolic INTEGER, " +
            "diastolic INTEGER, " +
            "pulse INTEGER, " +
            "notes TEXT, " +
            "created_at INTEGER NOT NULL" +
            ")"
        );
        db.execSQL("CREATE INDEX idx_readings_date_time ON readings(date, time)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        // Future migrations go here.
    }

    public long insertReading(String date, String time, String context, Double sugar,
                              Integer systolic, Integer diastolic, Integer pulse, String notes) {
        ContentValues values = new ContentValues();
        values.put("date", date);
        values.put("time", time);
        values.put("context", context);
        if (sugar != null) values.put("sugar", sugar);
        if (systolic != null) values.put("systolic", systolic);
        if (diastolic != null) values.put("diastolic", diastolic);
        if (pulse != null) values.put("pulse", pulse);
        values.put("notes", notes == null ? "" : notes);
        values.put("created_at", System.currentTimeMillis());
        return getWritableDatabase().insert("readings", null, values);
    }

    public void deleteReading(long id) {
        getWritableDatabase().delete("readings", "id=?", new String[]{String.valueOf(id)});
    }

    public List<Reading> getAllReadings() {
        Cursor c = getReadableDatabase().rawQuery(
            "SELECT * FROM readings ORDER BY date DESC, time DESC, id DESC", null
        );
        return readCursor(c);
    }

    public List<Reading> getReadingsSince(String startDate) {
        Cursor c = getReadableDatabase().rawQuery(
            "SELECT * FROM readings WHERE date >= ? ORDER BY date ASC, time ASC, id ASC",
            new String[]{startDate}
        );
        return readCursor(c);
    }

    private List<Reading> readCursor(Cursor c) {
        List<Reading> list = new ArrayList<>();
        try {
            while (c.moveToNext()) {
                Reading r = new Reading();
                r.id = c.getLong(c.getColumnIndexOrThrow("id"));
                r.date = c.getString(c.getColumnIndexOrThrow("date"));
                r.time = c.getString(c.getColumnIndexOrThrow("time"));
                r.context = c.getString(c.getColumnIndexOrThrow("context"));
                int sugarIndex = c.getColumnIndexOrThrow("sugar");
                int sysIndex = c.getColumnIndexOrThrow("systolic");
                int diaIndex = c.getColumnIndexOrThrow("diastolic");
                int pulseIndex = c.getColumnIndexOrThrow("pulse");
                r.sugar = c.isNull(sugarIndex) ? null : c.getDouble(sugarIndex);
                r.systolic = c.isNull(sysIndex) ? null : c.getInt(sysIndex);
                r.diastolic = c.isNull(diaIndex) ? null : c.getInt(diaIndex);
                r.pulse = c.isNull(pulseIndex) ? null : c.getInt(pulseIndex);
                r.notes = c.getString(c.getColumnIndexOrThrow("notes"));
                r.createdAt = c.getLong(c.getColumnIndexOrThrow("created_at"));
                list.add(r);
            }
        } finally {
            c.close();
        }
        return list;
    }

    public JSONArray toJsonArray() throws Exception {
        JSONArray arr = new JSONArray();
        for (Reading r : getAllReadings()) {
            JSONObject o = new JSONObject();
            o.put("id", r.id);
            o.put("date", r.date);
            o.put("time", r.time);
            o.put("context", r.context);
            o.put("sugar", r.sugar);
            o.put("systolic", r.systolic);
            o.put("diastolic", r.diastolic);
            o.put("pulse", r.pulse);
            o.put("notes", r.notes);
            o.put("createdAt", r.createdAt);
            arr.put(o);
        }
        return arr;
    }
}
