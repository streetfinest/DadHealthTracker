plugins {
    alias(libs.plugins.android.application)
}

android {
    namespace = "com.streetfinest.dadhealthtracker"
    compileSdk = 36

    defaultConfig {
        applicationId = "com.streetfinest.dadhealthtracker"
        minSdk = 23
        targetSdk = 36
        versionCode = 1
        versionName = "0.1.0"
    }
}
