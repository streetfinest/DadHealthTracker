# Notes

This version is deliberately simple.

It avoids:
- Kotlin compiler issues
- Jetpack Compose dependency issues
- Room/KSP setup issues

After the APK builds and installs, we can improve UI and add:
- restore backup
- PDF export
- share report button
- Swahili mode
