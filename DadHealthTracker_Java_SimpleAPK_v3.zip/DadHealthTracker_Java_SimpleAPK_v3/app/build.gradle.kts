plugins {
    alias(libs.plugins.android.application)
}

android {
    namespace = "com.streetfinest.dadhealthtracker"
    compileSdk = 36

    defaultConfig {
        applicationId = "com.streetfinest.dadhealthtracker"
        minSdk = 26
        targetSdk = 36
        versionCode = 3
        versionName = "0.3.0"
    }
}
