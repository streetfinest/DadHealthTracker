package com.streetfinest.dadhealthtracker;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import org.json.JSONArray;
import org.json.JSONObject;
import java.util.ArrayList;
import java.util.List;

public class HealthDbHelper extends SQLiteOpenHelper {
    private static final String DB_NAME = "dad_health_tracker_v3.db";
    private static final int DB_VERSION = 1;

    public static class SugarReading {
        public long id;
        public String date;
        public String entryTime;
        public String meal;
        public String timing;
        public Double value;
        public String notes;
        public long createdAt;
    }

    public static class BpReading {
        public long id;
        public String date;
        public String entryTime;
        public String period;
        public Integer systolic;
        public Integer diastolic;
        public Integer pulse;
        public String notes;
        public long createdAt;
    }

    public HealthDbHelper(Context context) {
        super(context, DB_NAME, null, DB_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(
            "CREATE TABLE sugar_readings (" +
            "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
            "date TEXT NOT NULL, " +
            "entry_time TEXT NOT NULL, " +
            "meal TEXT NOT NULL, " +
            "timing TEXT NOT NULL, " +
            "value REAL NOT NULL, " +
            "notes TEXT, " +
            "created_at INTEGER NOT NULL" +
            ")"
        );
        db.execSQL("CREATE INDEX idx_sugar_date ON sugar_readings(date, meal, timing)");

        db.execSQL(
            "CREATE TABLE bp_readings (" +
            "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
            "date TEXT NOT NULL, " +
            "entry_time TEXT NOT NULL, " +
            "period TEXT NOT NULL, " +
            "systolic INTEGER NOT NULL, " +
            "diastolic INTEGER NOT NULL, " +
            "pulse INTEGER, " +
            "notes TEXT, " +
            "created_at INTEGER NOT NULL" +
            ")"
        );
        db.execSQL("CREATE INDEX idx_bp_date ON bp_readings(date, period)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {}

    public long insertSugar(String date, String entryTime, String meal, String timing, Double value, String notes) {
        ContentValues values = new ContentValues();
        values.put("date", date);
        values.put("entry_time", entryTime);
        values.put("meal", meal);
        values.put("timing", timing);
        values.put("value", value);
        values.put("notes", notes == null ? "" : notes);
        values.put("created_at", System.currentTimeMillis());
        return getWritableDatabase().insert("sugar_readings", null, values);
    }

    public long insertBp(String date, String entryTime, String period, Integer systolic, Integer diastolic, Integer pulse, String notes) {
        ContentValues values = new ContentValues();
        values.put("date", date);
        values.put("entry_time", entryTime);
        values.put("period", period);
        values.put("systolic", systolic);
        values.put("diastolic", diastolic);
        if (pulse != null) values.put("pulse", pulse);
        values.put("notes", notes == null ? "" : notes);
        values.put("created_at", System.currentTimeMillis());
        return getWritableDatabase().insert("bp_readings", null, values);
    }

    public void deleteSugar(long id) {
        getWritableDatabase().delete("sugar_readings", "id=?", new String[]{String.valueOf(id)});
    }

    public void deleteBp(long id) {
        getWritableDatabase().delete("bp_readings", "id=?", new String[]{String.valueOf(id)});
    }

    public List<SugarReading> getAllSugar() {
        Cursor c = getReadableDatabase().rawQuery(
            "SELECT * FROM sugar_readings ORDER BY date DESC, entry_time DESC, id DESC", null
        );
        return readSugarCursor(c);
    }

    public List<BpReading> getAllBp() {
        Cursor c = getReadableDatabase().rawQuery(
            "SELECT * FROM bp_readings ORDER BY date DESC, entry_time DESC, id DESC", null
        );
        return readBpCursor(c);
    }

    public List<SugarReading> getSugarSince(String startDate) {
        Cursor c = getReadableDatabase().rawQuery(
            "SELECT * FROM sugar_readings WHERE date >= ? ORDER BY date ASC, meal ASC, timing ASC, id ASC",
            new String[]{startDate}
        );
        return readSugarCursor(c);
    }

    public List<BpReading> getBpSince(String startDate) {
        Cursor c = getReadableDatabase().rawQuery(
            "SELECT * FROM bp_readings WHERE date >= ? ORDER BY date ASC, period ASC, id ASC",
            new String[]{startDate}
        );
        return readBpCursor(c);
    }

    private List<SugarReading> readSugarCursor(Cursor c) {
        List<SugarReading> list = new ArrayList<>();
        try {
            while (c.moveToNext()) {
                SugarReading r = new SugarReading();
                r.id = c.getLong(c.getColumnIndexOrThrow("id"));
                r.date = c.getString(c.getColumnIndexOrThrow("date"));
                r.entryTime = c.getString(c.getColumnIndexOrThrow("entry_time"));
                r.meal = c.getString(c.getColumnIndexOrThrow("meal"));
                r.timing = c.getString(c.getColumnIndexOrThrow("timing"));
                r.value = c.getDouble(c.getColumnIndexOrThrow("value"));
                r.notes = c.getString(c.getColumnIndexOrThrow("notes"));
                r.createdAt = c.getLong(c.getColumnIndexOrThrow("created_at"));
                list.add(r);
            }
        } finally {
            c.close();
        }
        return list;
    }

    private List<BpReading> readBpCursor(Cursor c) {
        List<BpReading> list = new ArrayList<>();
        try {
            while (c.moveToNext()) {
                BpReading r = new BpReading();
                r.id = c.getLong(c.getColumnIndexOrThrow("id"));
                r.date = c.getString(c.getColumnIndexOrThrow("date"));
                r.entryTime = c.getString(c.getColumnIndexOrThrow("entry_time"));
                r.period = c.getString(c.getColumnIndexOrThrow("period"));
                r.systolic = c.getInt(c.getColumnIndexOrThrow("systolic"));
                r.diastolic = c.getInt(c.getColumnIndexOrThrow("diastolic"));
                int pulseIndex = c.getColumnIndexOrThrow("pulse");
                r.pulse = c.isNull(pulseIndex) ? null : c.getInt(pulseIndex);
                r.notes = c.getString(c.getColumnIndexOrThrow("notes"));
                r.createdAt = c.getLong(c.getColumnIndexOrThrow("created_at"));
                list.add(r);
            }
        } finally {
            c.close();
        }
        return list;
    }

    public JSONArray sugarToJsonArray() throws Exception {
        JSONArray arr = new JSONArray();
        for (SugarReading r : getAllSugar()) {
            JSONObject o = new JSONObject();
            o.put("id", r.id);
            o.put("date", r.date);
            o.put("entryTime", r.entryTime);
            o.put("meal", r.meal);
            o.put("timing", r.timing);
            o.put("value", r.value);
            o.put("notes", r.notes);
            o.put("createdAt", r.createdAt);
            arr.put(o);
        }
        return arr;
    }

    public JSONArray bpToJsonArray() throws Exception {
        JSONArray arr = new JSONArray();
        for (BpReading r : getAllBp()) {
            JSONObject o = new JSONObject();
            o.put("id", r.id);
            o.put("date", r.date);
            o.put("entryTime", r.entryTime);
            o.put("period", r.period);
            o.put("systolic", r.systolic);
            o.put("diastolic", r.diastolic);
            o.put("pulse", r.pulse);
            o.put("notes", r.notes);
            o.put("createdAt", r.createdAt);
            arr.put(o);
        }
        return arr;
    }
}
