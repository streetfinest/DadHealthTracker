package com.streetfinest.dadhealthtracker;

import android.app.Activity;
import android.app.AlertDialog;
import android.os.Bundle;
import android.graphics.Color;
import android.graphics.Typeface;
import android.net.Uri;
import android.view.Gravity;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.content.Context;
import android.content.Intent;
import android.widget.*;
import org.json.JSONObject;
import java.io.OutputStream;
import java.text.DecimalFormat;
import java.time.LocalDate;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.*;

public class MainActivity extends Activity {
    private HealthDbHelper db;
    private final int TEAL = Color.rgb(15, 118, 110);
    private final int TEAL_DARK = Color.rgb(7, 94, 87);
    private final int DARK = Color.rgb(17, 24, 39);
    private final int MUTED = Color.rgb(107, 114, 128);
    private final int BG = Color.rgb(246, 247, 246);
    private final int LIGHT_TEAL = Color.rgb(230, 255, 251);
    private final int LINE = Color.rgb(229, 231, 235);
    private final DecimalFormat oneDp = new DecimalFormat("0.0");

    private static final int REQUEST_SAVE_FILE = 4401;
    private String pendingFileContent = "";
    private String pendingMimeType = "text/plain";
    private String pendingFilename = "dad_health_export.txt";

    private final String[] sugarMeals = {"Breakfast", "Lunch", "Dinner"};
    private final String[] bpPeriods = {"Morning", "Afternoon", "Evening"};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        db = new HealthDbHelper(this);
        showHome();
    }

    private TextView tv(String text, int sp, int color, int style) {
        TextView v = new TextView(this);
        v.setText(text);
        v.setTextSize(sp);
        v.setTextColor(color);
        v.setTypeface(Typeface.DEFAULT, style);
        v.setPadding(dp(4), dp(4), dp(4), dp(4));
        return v;
    }

    private TextView label(String text) {
        return tv(text, 14, DARK, Typeface.BOLD);
    }

    private EditText input(String hint) {
        EditText e = new EditText(this);
        e.setHint(hint);
        e.setTextSize(17);
        e.setSingleLine(true);
        e.setPadding(dp(10), dp(9), dp(10), dp(9));
        e.setBackgroundColor(Color.WHITE);
        e.setLayoutParams(new LinearLayout.LayoutParams(-1, -2));
        return e;
    }

    private EditText numberInput(String hint) {
        EditText e = input(hint);
        e.setInputType(android.text.InputType.TYPE_CLASS_NUMBER | android.text.InputType.TYPE_NUMBER_FLAG_DECIMAL);
        return e;
    }

    private Button button(String text) {
        Button b = new Button(this);
        b.setText(text);
        b.setTextSize(16);
        b.setAllCaps(false);
        b.setTextColor(Color.WHITE);
        b.setBackgroundColor(TEAL);
        b.setPadding(dp(12), dp(10), dp(12), dp(10));
        return b;
    }

    private Button outlineButton(String text) {
        Button b = new Button(this);
        b.setText(text);
        b.setTextSize(15);
        b.setAllCaps(false);
        b.setTextColor(TEAL);
        b.setBackgroundColor(Color.WHITE);
        b.setPadding(dp(12), dp(10), dp(12), dp(10));
        return b;
    }

    private LinearLayout base(String title) {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(BG);

        LinearLayout header = new LinearLayout(this);
        header.setOrientation(LinearLayout.VERTICAL);
        header.setBackgroundColor(TEAL_DARK);
        header.setPadding(dp(18), dp(20), dp(18), dp(16));
        header.addView(tv(title, 24, Color.WHITE, Typeface.BOLD));
        root.addView(header, new LinearLayout.LayoutParams(-1, -2));
        return root;
    }

    private LinearLayout contentArea(LinearLayout root) {
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(false);
        scroll.setSmoothScrollingEnabled(true);
        scroll.setDescendantFocusability(android.view.ViewGroup.FOCUS_AFTER_DESCENDANTS);

        LinearLayout content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(dp(14), dp(14), dp(14), dp(24));
        scroll.addView(content);
        root.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1));
        return content;
    }

    private void addNav(LinearLayout root, String active) {
        LinearLayout nav = new LinearLayout(this);
        nav.setOrientation(LinearLayout.HORIZONTAL);
        nav.setGravity(Gravity.CENTER);
        nav.setPadding(dp(4), dp(5), dp(4), dp(5));
        nav.setBackgroundColor(Color.WHITE);

        String[] names = {"Home", "Add", "History", "Reports", "Backup"};
        for (String n : names) {
            Button b = new Button(this);
            b.setText(n);
            b.setTextSize(11);
            b.setAllCaps(false);
            b.setTextColor(n.equals(active) ? Color.WHITE : TEAL);
            b.setBackgroundColor(n.equals(active) ? TEAL : Color.WHITE);
            b.setOnClickListener(v -> {
                hideKeyboard(v);
                if (n.equals("Home")) showHome();
                if (n.equals("Add")) showAdd();
                if (n.equals("History")) showHistory();
                if (n.equals("Reports")) showReports();
                if (n.equals("Backup")) showBackup();
            });
            nav.addView(b, new LinearLayout.LayoutParams(0, dp(54), 1));
        }
        root.addView(nav, new LinearLayout.LayoutParams(-1, -2));
    }

    private LinearLayout card(LinearLayout parent) {
        LinearLayout c = new LinearLayout(this);
        c.setOrientation(LinearLayout.VERTICAL);
        c.setPadding(dp(14), dp(12), dp(14), dp(12));
        c.setBackgroundColor(Color.WHITE);
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, -2);
        p.setMargins(0, 0, 0, dp(12));
        parent.addView(c, p);
        return c;
    }

    private TextView sectionTitle(String title) {
        return tv(title, 20, TEAL_DARK, Typeface.BOLD);
    }

    private void showHome() {
        LinearLayout root = base("Dad Health Tracker");
        LinearLayout content = contentArea(root);

        content.addView(tv("Stay healthy, stay happy.", 16, MUTED, Typeface.NORMAL));

        Button add = button("+ Add New Reading");
        add.setOnClickListener(v -> showAdd());
        LinearLayout.LayoutParams addP = new LinearLayout.LayoutParams(-1, dp(58));
        addP.setMargins(0, dp(8), 0, dp(12));
        content.addView(add, addP);

        HealthDbHelper.SugarReading latestSugar = firstSugar();
        HealthDbHelper.BpReading latestBp = firstBp();

        LinearLayout sugarCard = card(content);
        sugarCard.addView(tv("Latest Sugar", 14, MUTED, Typeface.NORMAL));
        sugarCard.addView(tv(latestSugar == null ? "—" : oneDp.format(latestSugar.value) + " mmol/L", 30, DARK, Typeface.BOLD));
        sugarCard.addView(tv(latestSugar == null ? "No sugar readings yet" : latestSugar.meal + " " + latestSugar.timing + " • " + latestSugar.date, 14, MUTED, Typeface.NORMAL));

        LinearLayout bpCard = card(content);
        bpCard.addView(tv("Latest Blood Pressure", 14, MUTED, Typeface.NORMAL));
        bpCard.addView(tv(latestBp == null ? "—" : latestBp.systolic + "/" + latestBp.diastolic + " mmHg", 30, DARK, Typeface.BOLD));
        bpCard.addView(tv(latestBp == null ? "No BP readings yet" : latestBp.period + " • Pulse " + value(latestBp.pulse) + " • " + latestBp.date, 14, MUTED, Typeface.NORMAL));

        LinearLayout summary = card(content);
        summary.addView(sectionTitle("7-Day Summary"));
        List<HealthDbHelper.SugarReading> weekSugar = db.getSugarSince(LocalDate.now().minusDays(7).toString());
        List<HealthDbHelper.BpReading> weekBp = db.getBpSince(LocalDate.now().minusDays(7).toString());
        summary.addView(tv("Average sugar: " + avgSugar(weekSugar), 16, DARK, Typeface.NORMAL));
        summary.addView(tv("Average BP: " + avgBp(weekBp), 16, DARK, Typeface.NORMAL));
        summary.addView(tv("Sugar readings: " + weekSugar.size() + " | BP readings: " + weekBp.size(), 14, MUTED, Typeface.NORMAL));

        LinearLayout actions = card(content);
        actions.addView(sectionTitle("Quick Actions"));
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        Button hist = outlineButton("History");
        Button rep = outlineButton("Reports");
        hist.setOnClickListener(v -> showHistory());
        rep.setOnClickListener(v -> showReports());
        row.addView(hist, new LinearLayout.LayoutParams(0, dp(52), 1));
        row.addView(rep, new LinearLayout.LayoutParams(0, dp(52), 1));
        actions.addView(row);

        addNav(root, "Home");
        setContentView(root);
    }

    private void showAdd() {
        LinearLayout root = base("Add Reading");
        LinearLayout content = contentArea(root);

        LinearLayout general = card(content);
        general.addView(sectionTitle("General Info"));

        EditText date = input("YYYY-MM-DD");
        date.setText(LocalDate.now().toString());
        EditText entryTime = input("HH:mm");
        entryTime.setText(LocalTime.now().format(DateTimeFormatter.ofPattern("HH:mm")));

        general.addView(label("Date"));
        general.addView(date);
        general.addView(label("Entry Time"));
        general.addView(entryTime);

        LinearLayout sugarCard = card(content);
        sugarCard.addView(sectionTitle("Blood Sugar"));
        sugarCard.addView(tv("Fill only the readings measured. Empty boxes are okay.", 13, MUTED, Typeface.NORMAL));

        Map<String, EditText> sugarInputs = new LinkedHashMap<>();
        addSugarInputGrid(sugarCard, sugarInputs);

        EditText bedtime = numberInput("Bedtime sugar");
        sugarCard.addView(label("Bedtime"));
        sugarCard.addView(bedtime);
        sugarInputs.put("Bedtime|Bedtime", bedtime);

        EditText sugarNotes = input("Sugar notes optional");
        sugarCard.addView(label("Sugar Notes"));
        sugarCard.addView(sugarNotes);

        LinearLayout bpCard = card(content);
        bpCard.addView(sectionTitle("Blood Pressure"));
        bpCard.addView(tv("Enter systolic and diastolic together. Pulse is optional.", 13, MUTED, Typeface.NORMAL));

        Map<String, EditText[]> bpInputs = new LinkedHashMap<>();
        addBpInputGrid(bpCard, bpInputs);

        EditText bpNotes = input("BP notes optional");
        bpCard.addView(label("BP Notes"));
        bpCard.addView(bpNotes);

        Button save = button("✓ Save Reading");
        save.setOnClickListener(v -> {
            hideKeyboard(v);

            String d = date.getText().toString().trim();
            String t = entryTime.getText().toString().trim();
            String sugarNote = sugarNotes.getText().toString().trim();
            String bpNote = bpNotes.getText().toString().trim();

            if (d.isEmpty() || t.isEmpty()) {
                toast("Date and time are required.");
                return;
            }

            int saved = 0;

            for (Map.Entry<String, EditText> e : sugarInputs.entrySet()) {
                Double val = parseDouble(e.getValue().getText().toString());
                if (val != null) {
                    String[] parts = e.getKey().split("\\|");
                    db.insertSugar(d, t, parts[0], parts[1], val, sugarNote);
                    saved++;
                }
            }

            for (Map.Entry<String, EditText[]> e : bpInputs.entrySet()) {
                Integer sys = parseInt(e.getValue()[0].getText().toString());
                Integer dia = parseInt(e.getValue()[1].getText().toString());
                Integer pulse = parseInt(e.getValue()[2].getText().toString());

                if (sys != null || dia != null || pulse != null) {
                    if (sys == null || dia == null) {
                        toast("For BP, enter both systolic and diastolic.");
                        return;
                    }
                    db.insertBp(d, t, e.getKey(), sys, dia, pulse, bpNote);
                    saved++;
                }
            }

            if (saved == 0) {
                toast("Enter at least one sugar or BP reading.");
                return;
            }

            toast(saved + " reading(s) saved.");
            showHome();
        });

        LinearLayout.LayoutParams saveParams = new LinearLayout.LayoutParams(-1, dp(62));
        saveParams.setMargins(0, dp(4), 0, dp(14));
        content.addView(save, saveParams);

        addNav(root, "Add");
        setContentView(root);
    }

    private void addSugarInputGrid(LinearLayout parent, Map<String, EditText> inputs) {
        HorizontalScrollView hsv = new HorizontalScrollView(this);
        TableLayout table = new TableLayout(this);
        table.setStretchAllColumns(false);
        table.addView(row("Meal", "Before", "After", true));

        for (String meal : sugarMeals) {
            TableRow tr = new TableRow(this);
            tr.addView(cell(meal, true, 110));
            EditText before = numberInput("—");
            EditText after = numberInput("—");
            tr.addView(inputCell(before));
            tr.addView(inputCell(after));
            table.addView(tr);
            inputs.put(meal + "|Before", before);
            inputs.put(meal + "|After", after);
        }
        hsv.addView(table);
        parent.addView(hsv);
    }

    private void addBpInputGrid(LinearLayout parent, Map<String, EditText[]> inputs) {
        HorizontalScrollView hsv = new HorizontalScrollView(this);
        TableLayout table = new TableLayout(this);
        table.setStretchAllColumns(false);
        table.addView(row("Time", "Systolic", "Diastolic", "Pulse", true));

        for (String period : bpPeriods) {
            TableRow tr = new TableRow(this);
            tr.addView(cell(period, true, 110));
            EditText sys = numberInput("—");
            EditText dia = numberInput("—");
            EditText pulse = numberInput("—");
            tr.addView(inputCell(sys));
            tr.addView(inputCell(dia));
            tr.addView(inputCell(pulse));
            table.addView(tr);
            inputs.put(period, new EditText[]{sys, dia, pulse});
        }
        hsv.addView(table);
        parent.addView(hsv);
    }

    private TableRow row(String a, String b, String c, boolean header) {
        TableRow tr = new TableRow(this);
        tr.addView(cell(a, header, 120));
        tr.addView(cell(b, header, 120));
        tr.addView(cell(c, header, 120));
        return tr;
    }

    private TableRow row(String a, String b, String c, String d, boolean header) {
        TableRow tr = new TableRow(this);
        tr.addView(cell(a, header, 120));
        tr.addView(cell(b, header, 120));
        tr.addView(cell(c, header, 120));
        tr.addView(cell(d, header, 120));
        return tr;
    }

    private TextView cell(String text, boolean header, int widthDp) {
        TextView v = tv(text, header ? 13 : 14, header ? TEAL_DARK : DARK, header ? Typeface.BOLD : Typeface.NORMAL);
        v.setGravity(Gravity.CENTER);
        v.setBackgroundColor(header ? LIGHT_TEAL : Color.WHITE);
        v.setPadding(dp(8), dp(8), dp(8), dp(8));
        TableRow.LayoutParams p = new TableRow.LayoutParams(dp(widthDp), -2);
        v.setLayoutParams(p);
        return v;
    }

    private EditText inputCell(EditText editText) {
        editText.setGravity(Gravity.CENTER);
        editText.setTextSize(16);
        editText.setLayoutParams(new TableRow.LayoutParams(dp(120), -2));
        return editText;
    }

    private void showHistory() {
        LinearLayout root = base("History");
        LinearLayout content = contentArea(root);

        List<HealthDbHelper.SugarReading> sugarRows = db.getAllSugar();
        List<HealthDbHelper.BpReading> bpRows = db.getAllBp();

        LinearLayout sugarCard = card(content);
        sugarCard.addView(sectionTitle("Blood Sugar History"));
        sugarCard.addView(tv(sugarRows.size() + " sugar readings", 14, MUTED, Typeface.NORMAL));

        if (sugarRows.isEmpty()) {
            sugarCard.addView(tv("No sugar records yet.", 15, MUTED, Typeface.NORMAL));
        }

        for (HealthDbHelper.SugarReading r : sugarRows) {
            LinearLayout c = card(content);
            c.addView(tv(r.date + " • " + r.meal + " " + r.timing, 17, DARK, Typeface.BOLD));
            c.addView(tv("Sugar: " + oneDp.format(r.value) + " mmol/L", 16, DARK, Typeface.NORMAL));
            c.addView(tv("Entry time: " + r.entryTime, 14, MUTED, Typeface.NORMAL));
            if (r.notes != null && !r.notes.trim().isEmpty()) c.addView(tv("Notes: " + r.notes, 14, MUTED, Typeface.NORMAL));
            Button del = outlineButton("Delete Sugar");
            del.setOnClickListener(v -> confirmDelete("Delete sugar reading?", () -> { db.deleteSugar(r.id); showHistory(); }));
            c.addView(del);
        }

        LinearLayout bpHeader = card(content);
        bpHeader.addView(sectionTitle("Blood Pressure History"));
        bpHeader.addView(tv(bpRows.size() + " BP readings", 14, MUTED, Typeface.NORMAL));

        if (bpRows.isEmpty()) {
            bpHeader.addView(tv("No BP records yet.", 15, MUTED, Typeface.NORMAL));
        }

        for (HealthDbHelper.BpReading r : bpRows) {
            LinearLayout c = card(content);
            c.addView(tv(r.date + " • " + r.period, 17, DARK, Typeface.BOLD));
            c.addView(tv("BP: " + r.systolic + "/" + r.diastolic + " mmHg", 16, DARK, Typeface.NORMAL));
            c.addView(tv("Pulse: " + value(r.pulse) + " • Entry time: " + r.entryTime, 14, MUTED, Typeface.NORMAL));
            if (r.notes != null && !r.notes.trim().isEmpty()) c.addView(tv("Notes: " + r.notes, 14, MUTED, Typeface.NORMAL));
            Button del = outlineButton("Delete BP");
            del.setOnClickListener(v -> confirmDelete("Delete BP reading?", () -> { db.deleteBp(r.id); showHistory(); }));
            c.addView(del);
        }

        addNav(root, "History");
        setContentView(root);
    }

    private void showReports() {
        LinearLayout root = base("Reports");
        LinearLayout content = contentArea(root);

        addReportCard(content, "Weekly Report", 7);
        addReportCard(content, "Monthly Report", 30);

        LinearLayout info = card(content);
        info.addView(sectionTitle("Report Flow"));
        info.addView(tv("Preview first. Then save CSV. Wide tables scroll sideways.", 15, MUTED, Typeface.NORMAL));

        addNav(root, "Reports");
        setContentView(root);
    }

    private void addReportCard(LinearLayout content, String title, int days) {
        List<HealthDbHelper.SugarReading> sugar = db.getSugarSince(LocalDate.now().minusDays(days).toString());
        List<HealthDbHelper.BpReading> bp = db.getBpSince(LocalDate.now().minusDays(days).toString());

        LinearLayout c = card(content);
        c.addView(sectionTitle(title));
        c.addView(tv("Sugar readings: " + sugar.size(), 15, DARK, Typeface.NORMAL));
        c.addView(tv("BP readings: " + bp.size(), 15, DARK, Typeface.NORMAL));
        c.addView(tv("Average sugar: " + avgSugar(sugar), 15, DARK, Typeface.NORMAL));
        c.addView(tv("Average BP: " + avgBp(bp), 15, DARK, Typeface.NORMAL));

        Button preview = button("Preview " + days + "-Day Report");
        preview.setOnClickListener(v -> showReportPreview(title, days));
        c.addView(preview, new LinearLayout.LayoutParams(-1, dp(56)));
    }

    private void showReportPreview(String title, int days) {
        LinearLayout root = base(title + " Preview");
        LinearLayout content = contentArea(root);

        List<HealthDbHelper.SugarReading> sugar = db.getSugarSince(LocalDate.now().minusDays(days).toString());
        List<HealthDbHelper.BpReading> bp = db.getBpSince(LocalDate.now().minusDays(days).toString());

        LinearLayout summary = card(content);
        summary.addView(sectionTitle("Summary"));
        summary.addView(tv("Period: Last " + days + " days", 15, DARK, Typeface.NORMAL));
        summary.addView(tv("Average sugar: " + avgSugar(sugar), 15, DARK, Typeface.NORMAL));
        summary.addView(tv("Average BP: " + avgBp(bp), 15, DARK, Typeface.NORMAL));
        Button saveCsv = button("Save CSV File");
        saveCsv.setOnClickListener(v -> {
            String filename = "dad_health_" + days + "_day_report_" + LocalDate.now() + ".csv";
            saveFileWithPicker(buildCsv(sugar, bp), "text/csv", filename);
        });
        summary.addView(saveCsv, new LinearLayout.LayoutParams(-1, dp(56)));

        LinearLayout sugarCard = card(content);
        sugarCard.addView(sectionTitle("Blood Sugar Table"));
        sugarCard.addView(tv("Scroll sideways if columns are hidden.", 13, MUTED, Typeface.NORMAL));
        sugarCard.addView(buildSugarReportTable(sugar));

        LinearLayout bpCard = card(content);
        bpCard.addView(sectionTitle("Blood Pressure Table"));
        bpCard.addView(tv("Scroll sideways if columns are hidden.", 13, MUTED, Typeface.NORMAL));
        bpCard.addView(buildBpReportTable(bp));

        addNav(root, "Reports");
        setContentView(root);
    }

    private HorizontalScrollView buildSugarReportTable(List<HealthDbHelper.SugarReading> rows) {
        HorizontalScrollView hsv = new HorizontalScrollView(this);
        TableLayout table = new TableLayout(this);
        table.addView(reportRow(new String[]{"Date","Breakfast Before","Breakfast After","Lunch Before","Lunch After","Dinner Before","Dinner After","Bedtime"}, true));

        Map<String, Map<String, String>> byDate = new TreeMap<>();
        for (HealthDbHelper.SugarReading r : rows) {
            String key = r.meal.equals("Bedtime") ? "Bedtime" : r.meal + " " + r.timing;
            if (!byDate.containsKey(r.date)) byDate.put(r.date, new HashMap<>());
            byDate.get(r.date).put(key, oneDp.format(r.value));
        }

        for (String date : byDate.keySet()) {
            Map<String, String> m = byDate.get(date);
            table.addView(reportRow(new String[]{
                    date,
                    dash(m.get("Breakfast Before")),
                    dash(m.get("Breakfast After")),
                    dash(m.get("Lunch Before")),
                    dash(m.get("Lunch After")),
                    dash(m.get("Dinner Before")),
                    dash(m.get("Dinner After")),
                    dash(m.get("Bedtime"))
            }, false));
        }

        hsv.addView(table);
        return hsv;
    }

    private HorizontalScrollView buildBpReportTable(List<HealthDbHelper.BpReading> rows) {
        HorizontalScrollView hsv = new HorizontalScrollView(this);
        TableLayout table = new TableLayout(this);
        table.addView(reportRow(new String[]{"Date","Morning BP","Morning Pulse","Afternoon BP","Afternoon Pulse","Evening BP","Evening Pulse"}, true));

        Map<String, Map<String, HealthDbHelper.BpReading>> byDate = new TreeMap<>();
        for (HealthDbHelper.BpReading r : rows) {
            if (!byDate.containsKey(r.date)) byDate.put(r.date, new HashMap<>());
            byDate.get(r.date).put(r.period, r);
        }

        for (String date : byDate.keySet()) {
            Map<String, HealthDbHelper.BpReading> m = byDate.get(date);
            table.addView(reportRow(new String[]{
                    date,
                    bpValue(m.get("Morning")), pulseValue(m.get("Morning")),
                    bpValue(m.get("Afternoon")), pulseValue(m.get("Afternoon")),
                    bpValue(m.get("Evening")), pulseValue(m.get("Evening"))
            }, false));
        }

        hsv.addView(table);
        return hsv;
    }

    private TableRow reportRow(String[] values, boolean header) {
        TableRow tr = new TableRow(this);
        for (String v : values) {
            TextView cell = tv(v, header ? 12 : 13, header ? TEAL_DARK : DARK, header ? Typeface.BOLD : Typeface.NORMAL);
            cell.setGravity(Gravity.CENTER);
            cell.setBackgroundColor(header ? LIGHT_TEAL : Color.WHITE);
            cell.setPadding(dp(8), dp(8), dp(8), dp(8));
            tr.addView(cell, new TableRow.LayoutParams(dp(header ? 130 : 120), -2));
        }
        return tr;
    }

    private void showBackup() {
        LinearLayout root = base("Backup");
        LinearLayout content = contentArea(root);

        LinearLayout c = card(content);
        c.addView(sectionTitle("Backup Data"));
        c.addView(tv("Sugar readings: " + db.getAllSugar().size(), 15, DARK, Typeface.NORMAL));
        c.addView(tv("BP readings: " + db.getAllBp().size(), 15, DARK, Typeface.NORMAL));
        c.addView(tv("Save a backup before changing phones or deleting the app.", 14, MUTED, Typeface.NORMAL));

        Button backup = button("Save Backup File");
        backup.setOnClickListener(v -> exportBackup());
        c.addView(backup, new LinearLayout.LayoutParams(-1, dp(56)));

        LinearLayout c2 = card(content);
        c2.addView(sectionTitle("Restore Backup"));
        c2.addView(tv("Restore will be added in v4 after v3 passes testing.", 15, MUTED, Typeface.NORMAL));

        addNav(root, "Backup");
        setContentView(root);
    }

    private String buildCsv(List<HealthDbHelper.SugarReading> sugar, List<HealthDbHelper.BpReading> bp) {
        StringBuilder sb = new StringBuilder();
        sb.append("BLOOD SUGAR REPORT\n");
        sb.append("Date,Meal,Timing,Sugar Value,Entry Time,Notes\n");
        for (HealthDbHelper.SugarReading r : sugar) {
            sb.append(csv(r.date)).append(",")
                    .append(csv(r.meal)).append(",")
                    .append(csv(r.timing)).append(",")
                    .append(csv(oneDp.format(r.value))).append(",")
                    .append(csv(r.entryTime)).append(",")
                    .append(csv(r.notes)).append("\n");
        }
        sb.append("\nBLOOD PRESSURE REPORT\n");
        sb.append("Date,Period,Systolic,Diastolic,Pulse,Entry Time,Notes\n");
        for (HealthDbHelper.BpReading r : bp) {
            sb.append(csv(r.date)).append(",")
                    .append(csv(r.period)).append(",")
                    .append(csv(String.valueOf(r.systolic))).append(",")
                    .append(csv(String.valueOf(r.diastolic))).append(",")
                    .append(csv(value(r.pulse))).append(",")
                    .append(csv(r.entryTime)).append(",")
                    .append(csv(r.notes)).append("\n");
        }
        return sb.toString();
    }

    private void exportBackup() {
        try {
            JSONObject root = new JSONObject();
            root.put("app", "Dad Health Tracker");
            root.put("backupDate", LocalDate.now().toString());
            root.put("version", 3);
            root.put("sugarReadings", db.sugarToJsonArray());
            root.put("bpReadings", db.bpToJsonArray());
            String filename = "dad_health_backup_" + LocalDate.now() + ".json";
            saveFileWithPicker(root.toString(2), "application/json", filename);
        } catch (Exception e) {
            toast("Backup failed: " + e.getMessage());
        }
    }

    private void saveFileWithPicker(String content, String mimeType, String filename) {
        pendingFileContent = content;
        pendingMimeType = mimeType;
        pendingFilename = filename;

        Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType(mimeType);
        intent.putExtra(Intent.EXTRA_TITLE, filename);
        startActivityForResult(intent, REQUEST_SAVE_FILE);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == REQUEST_SAVE_FILE) {
            if (resultCode == RESULT_OK && data != null && data.getData() != null) {
                Uri uri = data.getData();
                try {
                    OutputStream out = getContentResolver().openOutputStream(uri);
                    if (out == null) {
                        toast("Could not open selected file.");
                        return;
                    }
                    out.write(pendingFileContent.getBytes("UTF-8"));
                    out.close();
                    toast("Saved successfully.");
                } catch (Exception e) {
                    toast("Save failed: " + e.getMessage());
                }
            } else {
                toast("Save cancelled.");
            }
        }
        super.onActivityResult(requestCode, resultCode, data);
    }

    private HealthDbHelper.SugarReading firstSugar() {
        List<HealthDbHelper.SugarReading> rows = db.getAllSugar();
        return rows.isEmpty() ? null : rows.get(0);
    }

    private HealthDbHelper.BpReading firstBp() {
        List<HealthDbHelper.BpReading> rows = db.getAllBp();
        return rows.isEmpty() ? null : rows.get(0);
    }

    private String avgSugar(List<HealthDbHelper.SugarReading> rows) {
        double sum = 0; int count = 0;
        for (HealthDbHelper.SugarReading r : rows) {
            if (r.value != null) { sum += r.value; count++; }
        }
        return count == 0 ? "—" : oneDp.format(sum / count);
    }

    private String avgBp(List<HealthDbHelper.BpReading> rows) {
        double sys = 0, dia = 0; int count = 0;
        for (HealthDbHelper.BpReading r : rows) {
            if (r.systolic != null && r.diastolic != null) {
                sys += r.systolic; dia += r.diastolic; count++;
            }
        }
        return count == 0 ? "—" : Math.round(sys / count) + "/" + Math.round(dia / count);
    }

    private String bpValue(HealthDbHelper.BpReading r) {
        return r == null ? "—" : r.systolic + "/" + r.diastolic;
    }

    private String pulseValue(HealthDbHelper.BpReading r) {
        return r == null ? "—" : value(r.pulse);
    }

    private String value(Object o) {
        return o == null ? "—" : String.valueOf(o);
    }

    private String dash(String s) {
        return s == null || s.trim().isEmpty() ? "—" : s;
    }

    private Double parseDouble(String s) {
        try {
            s = s.trim();
            if (s.isEmpty()) return null;
            return Double.parseDouble(s);
        } catch (Exception e) {
            return null;
        }
    }

    private Integer parseInt(String s) {
        try {
            s = s.trim();
            if (s.isEmpty()) return null;
            return Integer.parseInt(s);
        } catch (Exception e) {
            return null;
        }
    }

    private String csv(String s) {
        if (s == null) s = "";
        return "\"" + s.replace("\"", "\"\"") + "\"";
    }

    private void confirmDelete(String title, Runnable action) {
        new AlertDialog.Builder(this)
                .setTitle(title)
                .setMessage("This removes the selected record from this phone.")
                .setPositiveButton("Delete", (dialog, which) -> action.run())
                .setNegativeButton("Cancel", null)
                .show();
    }

    private void toast(String message) {
        Toast.makeText(this, message, Toast.LENGTH_LONG).show();
    }

    private int dp(int v) {
        return Math.round(v * getResources().getDisplayMetrics().density);
    }

    private void hideKeyboard(View v) {
        try {
            InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
            imm.hideSoftInputFromWindow(v.getWindowToken(), 0);
        } catch (Exception ignored) {}
    }
}
