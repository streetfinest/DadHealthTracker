# Dad Health Tracker — Java Simple APK v3

This version implements the approved v3 direction.

## v3 Features

- Custom app logo
- Keyboard-safe scrolling using `adjustResize`
- Separated Blood Sugar and Blood Pressure data tables
- Sugar input: Breakfast/Lunch/Dinner Before & After plus Bedtime
- BP input: Morning/Afternoon/Evening with Systolic, Diastolic, Pulse
- Improved dashboard
- Separate history for Sugar and BP records
- Report preview before export
- Horizontal-scroll report tables
- CSV export with Android save-location picker
- Backup export with Android save-location picker

## Important

This app uses a new v3 database:
`dad_health_tracker_v3.db`

Old v2 test records will not appear automatically because the data structure changed.
