# v3 Test Plan

## Keyboard Test
- Open Add screen
- Tap the lowest input field
- Confirm the keyboard appears
- Confirm screen can still scroll
- Confirm Save Reading button can be reached

## Add Reading Test
- Add breakfast before sugar
- Add lunch after sugar
- Add bedtime sugar
- Add morning BP
- Add evening BP
- Save
- Confirm dashboard updates

## History Test
- Confirm sugar records appear separately
- Confirm BP records appear separately
- Delete one sugar record
- Delete one BP record

## Report Test
- Open Weekly Report
- Confirm sugar table appears
- Confirm BP table appears
- Confirm sideways scroll works
- Save CSV and choose Downloads/Documents

## Backup Test
- Open Backup
- Save Backup File
- Choose location
- Confirm JSON file saves
