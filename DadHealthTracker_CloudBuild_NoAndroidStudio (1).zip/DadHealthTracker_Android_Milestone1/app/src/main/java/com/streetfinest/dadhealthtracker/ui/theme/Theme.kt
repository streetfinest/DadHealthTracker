package com.streetfinest.dadhealthtracker.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val LightColors = lightColorScheme(
    primary = Color(0xFF0F766E),
    secondary = Color(0xFF0D9488),
    background = Color(0xFFF6F7F6),
    surface = Color.White,
    error = Color(0xFFB91C1C)
)

@Composable
fun DadHealthTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = LightColors,
        content = content
    )
}
