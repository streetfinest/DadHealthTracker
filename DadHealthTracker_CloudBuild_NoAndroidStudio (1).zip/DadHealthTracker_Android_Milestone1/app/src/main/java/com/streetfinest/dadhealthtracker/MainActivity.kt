package com.streetfinest.dadhealthtracker

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.lifecycle.viewmodel.compose.viewModel
import com.streetfinest.dadhealthtracker.ui.DadHealthApp
import com.streetfinest.dadhealthtracker.ui.DadHealthViewModel
import com.streetfinest.dadhealthtracker.ui.theme.DadHealthTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            DadHealthTheme {
                val appViewModel: DadHealthViewModel = viewModel(
                    factory = DadHealthViewModel.Factory(application)
                )
                DadHealthApp(viewModel = appViewModel)
            }
        }
    }
}
