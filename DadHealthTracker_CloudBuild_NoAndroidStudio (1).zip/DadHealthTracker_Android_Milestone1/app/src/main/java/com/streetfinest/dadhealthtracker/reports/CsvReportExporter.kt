package com.streetfinest.dadhealthtracker.reports

import android.content.Context
import android.content.Intent
import android.os.Environment
import androidx.core.content.FileProvider
import com.streetfinest.dadhealthtracker.data.Reading
import java.io.File
import java.time.LocalDate
import java.time.format.DateTimeFormatter

object CsvReportExporter {
    fun exportAndShare(context: Context, readings: List<Reading>, days: Int) {
        val now = LocalDate.now()
        val filename = "dad_health_${days}_day_report_${now.format(DateTimeFormatter.ISO_DATE)}.csv"
        val folder = context.getExternalFilesDir(Environment.DIRECTORY_DOCUMENTS) ?: context.filesDir
        val file = File(folder, filename)

        val csv = buildString {
            appendLine("Date,Time,Reading Context,Blood Sugar,Systolic BP,Diastolic BP,Pulse,Notes")
            readings.forEach { r ->
                appendLine(
                    listOf(
                        r.date,
                        r.time,
                        r.context,
                        r.bloodSugar?.toString().orEmpty(),
                        r.systolicBp?.toString().orEmpty(),
                        r.diastolicBp?.toString().orEmpty(),
                        r.pulse?.toString().orEmpty(),
                        r.notes.orEmpty()
                    ).joinToString(",") { it.csvEscape() }
                )
            }
        }

        file.writeText(csv)

        val uri = FileProvider.getUriForFile(
            context,
            "${context.packageName}.fileprovider",
            file
        )

        val sendIntent = Intent(Intent.ACTION_SEND).apply {
            type = "text/csv"
            putExtra(Intent.EXTRA_STREAM, uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }

        context.startActivity(Intent.createChooser(sendIntent, "Share CSV report"))
    }

    private fun String.csvEscape(): String {
        val escaped = replace(""", """")
        return ""$escaped""
    }
}
