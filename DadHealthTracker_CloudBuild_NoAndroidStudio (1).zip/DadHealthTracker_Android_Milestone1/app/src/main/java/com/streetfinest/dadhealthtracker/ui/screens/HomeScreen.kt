package com.streetfinest.dadhealthtracker.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.weight
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.streetfinest.dadhealthtracker.data.Reading
import com.streetfinest.dadhealthtracker.ui.averageDouble
import com.streetfinest.dadhealthtracker.ui.averageInt
import com.streetfinest.dadhealthtracker.ui.bpText
import com.streetfinest.dadhealthtracker.ui.withinDays

@Composable
fun HomeScreen(
    readings: List<Reading>,
    onAddClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val latest = readings.firstOrNull()
    val last7 = readings.withinDays(7)
    val last30 = readings.withinDays(30)

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text(
                    text = "Dad Health Tracker",
                    style = MaterialTheme.typography.headlineMedium,
                    fontWeight = FontWeight.ExtraBold
                )
                Text(
                    text = "Sugar and blood pressure record",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.outline
                )
            }
        }

        item {
            Button(
                onClick = onAddClick,
                modifier = Modifier.fillMaxWidth(),
                contentPadding = PaddingValues(18.dp)
            ) {
                Text("Add New Reading", style = MaterialTheme.typography.titleMedium)
            }
        }

        item {
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                MetricCard(
                    title = "Latest Sugar",
                    value = latest?.bloodSugar?.toString() ?: "—",
                    subtitle = "mmol/L",
                    modifier = Modifier.weight(1f)
                )
                MetricCard(
                    title = "Latest BP",
                    value = bpText(latest),
                    subtitle = "mmHg",
                    modifier = Modifier.weight(1f)
                )
            }
        }

        item {
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                MetricCard(
                    title = "Latest Pulse",
                    value = latest?.pulse?.toString() ?: "—",
                    subtitle = "beats/min",
                    modifier = Modifier.weight(1f)
                )
                MetricCard(
                    title = "Entries",
                    value = readings.size.toString(),
                    subtitle = "total saved",
                    modifier = Modifier.weight(1f)
                )
            }
        }

        item {
            Text("7-Day Summary", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
        }

        item {
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                MetricCard(
                    title = "Avg Sugar",
                    value = averageDouble(last7.map { it.bloodSugar }),
                    subtitle = "last 7 days",
                    modifier = Modifier.weight(1f)
                )
                MetricCard(
                    title = "Avg BP",
                    value = "${averageInt(last7.map { it.systolicBp })}/${averageInt(last7.map { it.diastolicBp })}",
                    subtitle = "last 7 days",
                    modifier = Modifier.weight(1f)
                )
            }
        }

        item {
            Text("30-Day Summary", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
        }

        item {
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                MetricCard(
                    title = "Avg Sugar",
                    value = averageDouble(last30.map { it.bloodSugar }),
                    subtitle = "last 30 days",
                    modifier = Modifier.weight(1f)
                )
                MetricCard(
                    title = "Avg BP",
                    value = "${averageInt(last30.map { it.systolicBp })}/${averageInt(last30.map { it.diastolicBp })}",
                    subtitle = "last 30 days",
                    modifier = Modifier.weight(1f)
                )
            }
        }

        item {
            if (latest != null) {
                MetricCard(
                    title = "Latest Entry",
                    value = "${latest.date} at ${latest.time}",
                    subtitle = "${latest.context} • Sugar: ${latest.bloodSugar ?: "—"} • BP: ${bpText(latest)}"
                )
            } else {
                MetricCard(
                    title = "No readings yet",
                    value = "Tap Add",
                    subtitle = "Start by saving the first sugar or BP reading."
                )
            }
        }
    }
}
