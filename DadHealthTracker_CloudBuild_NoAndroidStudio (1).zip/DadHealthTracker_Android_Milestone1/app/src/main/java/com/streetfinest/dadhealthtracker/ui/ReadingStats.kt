package com.streetfinest.dadhealthtracker.ui

import com.streetfinest.dadhealthtracker.data.Reading
import java.time.LocalDate

fun List<Reading>.withinDays(days: Int): List<Reading> {
    val cutoff = LocalDate.now().minusDays(days.toLong())
    return filter { reading ->
        runCatching {
            !LocalDate.parse(reading.date).isBefore(cutoff)
        }.getOrDefault(false)
    }
}

fun averageDouble(values: List<Double?>): String {
    val clean = values.filterNotNull()
    if (clean.isEmpty()) return "—"
    return "%.1f".format(clean.average())
}

fun averageInt(values: List<Int?>): String {
    val clean = values.filterNotNull()
    if (clean.isEmpty()) return "—"
    return "%.0f".format(clean.average())
}

fun bpText(reading: Reading?): String {
    if (reading?.systolicBp == null || reading.diastolicBp == null) return "—"
    return "${reading.systolicBp}/${reading.diastolicBp}"
}
