package com.streetfinest.dadhealthtracker.ui

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AddCircle
import androidx.compose.material.icons.filled.Backup
import androidx.compose.material.icons.filled.Dashboard
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.InsertDriveFile
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.foundation.layout.padding
import com.streetfinest.dadhealthtracker.ui.screens.AddReadingScreen
import com.streetfinest.dadhealthtracker.ui.screens.BackupScreen
import com.streetfinest.dadhealthtracker.ui.screens.HistoryScreen
import com.streetfinest.dadhealthtracker.ui.screens.HomeScreen
import com.streetfinest.dadhealthtracker.ui.screens.ReportsScreen

enum class AppScreen(val label: String) {
    Home("Home"),
    Add("Add"),
    History("History"),
    Reports("Reports"),
    Backup("Backup")
}

@Composable
fun DadHealthApp(viewModel: DadHealthViewModel) {
    var currentScreen by remember { mutableStateOf(AppScreen.Home) }
    val readings by viewModel.readings.collectAsState()

    Scaffold(
        bottomBar = {
            NavigationBar {
                NavigationBarItem(
                    selected = currentScreen == AppScreen.Home,
                    onClick = { currentScreen = AppScreen.Home },
                    icon = { Icon(Icons.Default.Dashboard, contentDescription = "Home") },
                    label = { Text("Home") }
                )
                NavigationBarItem(
                    selected = currentScreen == AppScreen.Add,
                    onClick = { currentScreen = AppScreen.Add },
                    icon = { Icon(Icons.Default.AddCircle, contentDescription = "Add") },
                    label = { Text("Add") }
                )
                NavigationBarItem(
                    selected = currentScreen == AppScreen.History,
                    onClick = { currentScreen = AppScreen.History },
                    icon = { Icon(Icons.Default.History, contentDescription = "History") },
                    label = { Text("History") }
                )
                NavigationBarItem(
                    selected = currentScreen == AppScreen.Reports,
                    onClick = { currentScreen = AppScreen.Reports },
                    icon = { Icon(Icons.Default.InsertDriveFile, contentDescription = "Reports") },
                    label = { Text("Reports") }
                )
                NavigationBarItem(
                    selected = currentScreen == AppScreen.Backup,
                    onClick = { currentScreen = AppScreen.Backup },
                    icon = { Icon(Icons.Default.Backup, contentDescription = "Backup") },
                    label = { Text("Backup") }
                )
            }
        }
    ) { innerPadding ->
        val modifier = Modifier.padding(innerPadding)
        when (currentScreen) {
            AppScreen.Home -> HomeScreen(
                readings = readings,
                onAddClick = { currentScreen = AppScreen.Add },
                modifier = modifier
            )
            AppScreen.Add -> AddReadingScreen(
                onSave = { date, time, context, sugar, sys, dia, pulse, notes ->
                    viewModel.addReading(date, time, context, sugar, sys, dia, pulse, notes)
                    currentScreen = AppScreen.Home
                },
                modifier = modifier
            )
            AppScreen.History -> HistoryScreen(
                readings = readings,
                onDelete = viewModel::deleteReading,
                modifier = modifier
            )
            AppScreen.Reports -> ReportsScreen(
                readings = readings,
                onExportCsv = viewModel::exportCsv,
                modifier = modifier
            )
            AppScreen.Backup -> BackupScreen(
                readings = readings,
                onExportBackup = viewModel::exportBackup,
                modifier = modifier
            )
        }
    }
}
