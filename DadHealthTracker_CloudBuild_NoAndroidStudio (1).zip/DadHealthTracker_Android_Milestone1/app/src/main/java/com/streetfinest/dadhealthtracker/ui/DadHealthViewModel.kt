package com.streetfinest.dadhealthtracker.ui

import android.app.Application
import android.content.Context
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.streetfinest.dadhealthtracker.backup.BackupExporter
import com.streetfinest.dadhealthtracker.data.DadHealthDatabase
import com.streetfinest.dadhealthtracker.data.Reading
import com.streetfinest.dadhealthtracker.data.ReadingRepository
import com.streetfinest.dadhealthtracker.reports.CsvReportExporter
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.time.LocalDate

class DadHealthViewModel(application: Application) : AndroidViewModel(application) {
    private val repository = ReadingRepository(
        DadHealthDatabase.getInstance(application).readingDao()
    )

    val readings: StateFlow<List<Reading>> = repository.observeAll()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    fun addReading(
        date: String,
        time: String,
        context: String,
        bloodSugar: Double?,
        systolicBp: Int?,
        diastolicBp: Int?,
        pulse: Int?,
        notes: String?
    ) {
        viewModelScope.launch {
            repository.addReading(
                Reading(
                    date = date,
                    time = time,
                    context = context,
                    bloodSugar = bloodSugar,
                    systolicBp = systolicBp,
                    diastolicBp = diastolicBp,
                    pulse = pulse,
                    notes = notes?.takeIf { it.isNotBlank() }
                )
            )
        }
    }

    fun deleteReading(reading: Reading) {
        viewModelScope.launch {
            repository.deleteReading(reading)
        }
    }

    fun exportCsv(context: Context, days: Int) {
        viewModelScope.launch {
            val end = LocalDate.now()
            val start = end.minusDays(days.toLong())
            val rows = repository.getReadingsBetween(start.toString(), end.toString())
            CsvReportExporter.exportAndShare(context, rows, days)
        }
    }

    fun exportBackup(context: Context) {
        BackupExporter.exportAndShare(context, readings.value)
    }

    class Factory(private val application: Application) : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T {
            return DadHealthViewModel(application) as T
        }
    }
}
