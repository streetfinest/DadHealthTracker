package com.streetfinest.dadhealthtracker.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.streetfinest.dadhealthtracker.data.Reading
import com.streetfinest.dadhealthtracker.ui.bpText

@Composable
fun HistoryScreen(
    readings: List<Reading>,
    onDelete: (Reading) -> Unit,
    modifier: Modifier = Modifier
) {
    var readingToDelete by remember { mutableStateOf<Reading?>(null) }

    if (readingToDelete != null) {
        AlertDialog(
            onDismissRequest = { readingToDelete = null },
            title = { Text("Delete reading?") },
            text = { Text("This removes the selected record from this phone.") },
            confirmButton = {
                Button(
                    onClick = {
                        readingToDelete?.let(onDelete)
                        readingToDelete = null
                    }
                ) { Text("Delete") }
            },
            dismissButton = {
                OutlinedButton(onClick = { readingToDelete = null }) { Text("Cancel") }
            }
        )
    }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Text("History", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.ExtraBold)
            Text("${readings.size} readings saved", color = MaterialTheme.colorScheme.outline)
        }

        if (readings.isEmpty()) {
            item {
                MetricCard(
                    title = "No records yet",
                    value = "Add first reading",
                    subtitle = "Saved readings will appear here."
                )
            }
        } else {
            items(readings, key = { it.id }) { reading ->
                ReadingHistoryCard(
                    reading = reading,
                    onDelete = { readingToDelete = reading }
                )
            }
        }
    }
}

@Composable
private fun ReadingHistoryCard(
    reading: Reading,
    onDelete: () -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Text(
                text = "${reading.date} at ${reading.time}",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold
            )
            Text(reading.context, color = MaterialTheme.colorScheme.outline)

            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Sugar: ${reading.bloodSugar ?: "—"}", fontWeight = FontWeight.SemiBold)
                Text("BP: ${bpText(reading)}", fontWeight = FontWeight.SemiBold)
            }

            Text("Pulse: ${reading.pulse ?: "—"}", fontWeight = FontWeight.SemiBold)

            if (!reading.notes.isNullOrBlank()) {
                Text(reading.notes, color = MaterialTheme.colorScheme.outline)
            }

            OutlinedButton(onClick = onDelete) {
                Text("Delete")
            }
        }
    }
}
