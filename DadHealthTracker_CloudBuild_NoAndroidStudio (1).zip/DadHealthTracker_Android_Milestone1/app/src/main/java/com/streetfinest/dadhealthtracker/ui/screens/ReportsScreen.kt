package com.streetfinest.dadhealthtracker.ui.screens

import android.content.Context
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.weight
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.streetfinest.dadhealthtracker.data.Reading
import com.streetfinest.dadhealthtracker.ui.averageDouble
import com.streetfinest.dadhealthtracker.ui.averageInt
import com.streetfinest.dadhealthtracker.ui.withinDays

@Composable
fun ReportsScreen(
    readings: List<Reading>,
    onExportCsv: (Context, Int) -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val weekly = readings.withinDays(7)
    val monthly = readings.withinDays(30)

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Text("Reports", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.ExtraBold)
            Text("Export weekly or monthly readings for clinic review.", color = MaterialTheme.colorScheme.outline)
        }

        item {
            Text("Weekly Summary", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
        }

        item {
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                MetricCard(
                    title = "Readings",
                    value = weekly.size.toString(),
                    subtitle = "last 7 days",
                    modifier = Modifier.weight(1f)
                )
                MetricCard(
                    title = "Avg Sugar",
                    value = averageDouble(weekly.map { it.bloodSugar }),
                    subtitle = "last 7 days",
                    modifier = Modifier.weight(1f)
                )
            }
        }

        item {
            MetricCard(
                title = "Avg BP",
                value = "${averageInt(weekly.map { it.systolicBp })}/${averageInt(weekly.map { it.diastolicBp })}",
                subtitle = "weekly average"
            )
        }

        item {
            Button(
                onClick = { onExportCsv(context, 7) },
                contentPadding = PaddingValues(18.dp)
            ) {
                Text("Export Weekly CSV")
            }
        }

        item {
            Text("Monthly Summary", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
        }

        item {
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                MetricCard(
                    title = "Readings",
                    value = monthly.size.toString(),
                    subtitle = "last 30 days",
                    modifier = Modifier.weight(1f)
                )
                MetricCard(
                    title = "Avg Sugar",
                    value = averageDouble(monthly.map { it.bloodSugar }),
                    subtitle = "last 30 days",
                    modifier = Modifier.weight(1f)
                )
            }
        }

        item {
            MetricCard(
                title = "Avg BP",
                value = "${averageInt(monthly.map { it.systolicBp })}/${averageInt(monthly.map { it.diastolicBp })}",
                subtitle = "monthly average"
            )
        }

        item {
            Button(
                onClick = { onExportCsv(context, 30) },
                contentPadding = PaddingValues(18.dp)
            ) {
                Text("Export Monthly CSV")
            }
        }

        item {
            MetricCard(
                title = "PDF report",
                value = "Next",
                subtitle = "PDF export will be added after the CSV system is tested."
            )
        }
    }
}
