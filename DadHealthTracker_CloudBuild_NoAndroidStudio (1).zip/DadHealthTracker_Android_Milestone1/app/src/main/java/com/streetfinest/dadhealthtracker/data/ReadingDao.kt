package com.streetfinest.dadhealthtracker.data

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface ReadingDao {
    @Insert
    suspend fun insert(reading: Reading)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(readings: List<Reading>)

    @Delete
    suspend fun delete(reading: Reading)

    @Query("DELETE FROM readings")
    suspend fun deleteAll()

    @Query("SELECT * FROM readings ORDER BY date DESC, time DESC, id DESC")
    fun observeAll(): Flow<List<Reading>>

    @Query("SELECT * FROM readings ORDER BY date DESC, time DESC, id DESC LIMIT 1")
    fun observeLatest(): Flow<Reading?>

    @Query("SELECT * FROM readings WHERE date >= :startDate AND date <= :endDate ORDER BY date ASC, time ASC, id ASC")
    suspend fun getReadingsBetween(startDate: String, endDate: String): List<Reading>
}
