package com.streetfinest.dadhealthtracker.backup

import android.content.Context
import android.content.Intent
import android.os.Environment
import androidx.core.content.FileProvider
import com.streetfinest.dadhealthtracker.data.Reading
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.time.LocalDate
import java.time.format.DateTimeFormatter

object BackupExporter {
    fun exportAndShare(context: Context, readings: List<Reading>) {
        val now = LocalDate.now()
        val filename = "dad_health_backup_${now.format(DateTimeFormatter.ISO_DATE)}.json"
        val folder = context.getExternalFilesDir(Environment.DIRECTORY_DOCUMENTS) ?: context.filesDir
        val file = File(folder, filename)

        val array = JSONArray()
        readings.forEach { r ->
            val obj = JSONObject()
            obj.put("id", r.id)
            obj.put("date", r.date)
            obj.put("time", r.time)
            obj.put("context", r.context)
            obj.put("bloodSugar", r.bloodSugar)
            obj.put("systolicBp", r.systolicBp)
            obj.put("diastolicBp", r.diastolicBp)
            obj.put("pulse", r.pulse)
            obj.put("notes", r.notes)
            obj.put("createdAt", r.createdAt)
            obj.put("updatedAt", r.updatedAt)
            array.put(obj)
        }

        val root = JSONObject()
        root.put("app", "Dad Health Tracker")
        root.put("backupDate", now.toString())
        root.put("version", 1)
        root.put("readings", array)

        file.writeText(root.toString(2))

        val uri = FileProvider.getUriForFile(
            context,
            "${context.packageName}.fileprovider",
            file
        )

        val sendIntent = Intent(Intent.ACTION_SEND).apply {
            type = "application/json"
            putExtra(Intent.EXTRA_STREAM, uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }

        context.startActivity(Intent.createChooser(sendIntent, "Share backup file"))
    }
}
