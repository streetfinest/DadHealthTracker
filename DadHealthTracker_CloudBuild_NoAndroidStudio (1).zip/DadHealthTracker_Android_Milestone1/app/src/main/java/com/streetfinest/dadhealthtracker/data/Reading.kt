package com.streetfinest.dadhealthtracker.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "readings")
data class Reading(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val date: String,
    val time: String,
    val context: String,
    val bloodSugar: Double? = null,
    val systolicBp: Int? = null,
    val diastolicBp: Int? = null,
    val pulse: Int? = null,
    val notes: String? = null,
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis()
)
