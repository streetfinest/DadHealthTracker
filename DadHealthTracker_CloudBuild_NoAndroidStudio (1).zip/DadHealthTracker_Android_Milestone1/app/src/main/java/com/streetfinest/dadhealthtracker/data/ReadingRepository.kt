package com.streetfinest.dadhealthtracker.data

import kotlinx.coroutines.flow.Flow

class ReadingRepository(private val dao: ReadingDao) {
    fun observeAll(): Flow<List<Reading>> = dao.observeAll()

    fun observeLatest(): Flow<Reading?> = dao.observeLatest()

    suspend fun addReading(reading: Reading) {
        dao.insert(reading)
    }

    suspend fun deleteReading(reading: Reading) {
        dao.delete(reading)
    }

    suspend fun getReadingsBetween(startDate: String, endDate: String): List<Reading> {
        return dao.getReadingsBetween(startDate, endDate)
    }

    suspend fun replaceAll(readings: List<Reading>) {
        dao.deleteAll()
        dao.insertAll(readings)
    }
}
