package com.streetfinest.dadhealthtracker.ui.screens

import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.Button
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import java.time.LocalDate
import java.time.LocalTime
import java.time.format.DateTimeFormatter

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun AddReadingScreen(
    onSave: (
        date: String,
        time: String,
        context: String,
        bloodSugar: Double?,
        systolicBp: Int?,
        diastolicBp: Int?,
        pulse: Int?,
        notes: String?
    ) -> Unit,
    modifier: Modifier = Modifier
) {
    val contexts = listOf(
        "Before breakfast",
        "After breakfast",
        "Before lunch",
        "After lunch",
        "Before dinner",
        "After dinner",
        "Bedtime",
        "Random check"
    )

    var date by remember { mutableStateOf(LocalDate.now().toString()) }
    var time by remember { mutableStateOf(LocalTime.now().format(DateTimeFormatter.ofPattern("HH:mm"))) }
    var context by remember { mutableStateOf(contexts.first()) }
    var sugar by remember { mutableStateOf("") }
    var sys by remember { mutableStateOf("") }
    var dia by remember { mutableStateOf("") }
    var pulse by remember { mutableStateOf("") }
    var notes by remember { mutableStateOf("") }
    var error by remember { mutableStateOf<String?>(null) }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Text("Add Reading", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.ExtraBold)
            Text("Enter sugar, blood pressure, pulse, and notes.", color = MaterialTheme.colorScheme.outline)
        }

        error?.let { message ->
            item {
                Text(message, color = MaterialTheme.colorScheme.error, fontWeight = FontWeight.Bold)
            }
        }

        item {
            OutlinedTextField(
                value = date,
                onValueChange = { date = it },
                label = { Text("Date") },
                placeholder = { Text("YYYY-MM-DD") },
                modifier = Modifier.fillMaxWidth()
            )
        }

        item {
            OutlinedTextField(
                value = time,
                onValueChange = { time = it },
                label = { Text("Time") },
                placeholder = { Text("HH:mm") },
                modifier = Modifier.fillMaxWidth()
            )
        }

        item {
            Text("Reading Time", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
        }

        item {
            FlowRow(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                contexts.forEach { item ->
                    FilterChip(
                        selected = context == item,
                        onClick = { context = item },
                        label = { Text(item) }
                    )
                }
            }
        }

        item {
            OutlinedTextField(
                value = sugar,
                onValueChange = { sugar = it },
                label = { Text("Blood sugar") },
                placeholder = { Text("Example: 8.7") },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                modifier = Modifier.fillMaxWidth()
            )
        }

        item {
            OutlinedTextField(
                value = sys,
                onValueChange = { sys = it },
                label = { Text("BP top number / Systolic") },
                placeholder = { Text("Example: 135") },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                modifier = Modifier.fillMaxWidth()
            )
        }

        item {
            OutlinedTextField(
                value = dia,
                onValueChange = { dia = it },
                label = { Text("BP bottom number / Diastolic") },
                placeholder = { Text("Example: 84") },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                modifier = Modifier.fillMaxWidth()
            )
        }

        item {
            OutlinedTextField(
                value = pulse,
                onValueChange = { pulse = it },
                label = { Text("Pulse") },
                placeholder = { Text("Optional") },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                modifier = Modifier.fillMaxWidth()
            )
        }

        item {
            OutlinedTextField(
                value = notes,
                onValueChange = { notes = it },
                label = { Text("Notes") },
                placeholder = { Text("Food, medicine, symptoms, or anything important") },
                minLines = 3,
                modifier = Modifier.fillMaxWidth()
            )
        }

        item {
            Button(
                onClick = {
                    val sugarValue = sugar.toDoubleOrNull()
                    val sysValue = sys.toIntOrNull()
                    val diaValue = dia.toIntOrNull()
                    val pulseValue = pulse.toIntOrNull()

                    error = when {
                        date.isBlank() -> "Date is required."
                        time.isBlank() -> "Time is required."
                        sugar.isNotBlank() && sugarValue == null -> "Blood sugar must be a number."
                        sys.isNotBlank() && sysValue == null -> "BP top number must be a number."
                        dia.isNotBlank() && diaValue == null -> "BP bottom number must be a number."
                        pulse.isNotBlank() && pulseValue == null -> "Pulse must be a number."
                        sugarValue == null && sysValue == null && diaValue == null -> "Enter blood sugar or BP."
                        (sysValue == null) != (diaValue == null) -> "Enter both BP top and bottom numbers."
                        else -> null
                    }

                    if (error == null) {
                        onSave(
                            date.trim(),
                            time.trim(),
                            context,
                            sugarValue,
                            sysValue,
                            diaValue,
                            pulseValue,
                            notes.trim()
                        )
                    }
                },
                modifier = Modifier.fillMaxWidth(),
                contentPadding = PaddingValues(18.dp)
            ) {
                Text("Save Reading", style = MaterialTheme.typography.titleMedium)
            }
        }
    }
}
