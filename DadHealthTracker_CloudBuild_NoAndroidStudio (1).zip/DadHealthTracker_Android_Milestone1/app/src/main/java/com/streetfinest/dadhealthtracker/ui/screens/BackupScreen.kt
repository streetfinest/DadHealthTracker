package com.streetfinest.dadhealthtracker.ui.screens

import android.content.Context
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.streetfinest.dadhealthtracker.data.Reading

@Composable
fun BackupScreen(
    readings: List<Reading>,
    onExportBackup: (Context) -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Text("Backup", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.ExtraBold)
            Text("Protect the records before changing phones or deleting the app.", color = MaterialTheme.colorScheme.outline)
        }

        item {
            MetricCard(
                title = "Saved readings",
                value = readings.size.toString(),
                subtitle = "records currently stored on this phone"
            )
        }

        item {
            Button(
                onClick = { onExportBackup(context) },
                contentPadding = PaddingValues(18.dp)
            ) {
                Text("Create Backup File")
            }
        }

        item {
            MetricCard(
                title = "Restore backup",
                value = "Next",
                subtitle = "Restore from backup will be added in Milestone 2."
            )
        }

        item {
            MetricCard(
                title = "Important",
                value = "Back up regularly",
                subtitle = "If the phone is lost or the app is deleted without backup, records can be lost."
            )
        }
    }
}
