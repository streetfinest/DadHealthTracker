package com.streetfinest.dadhealthtracker.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(
    entities = [Reading::class],
    version = 1,
    exportSchema = true
)
abstract class DadHealthDatabase : RoomDatabase() {
    abstract fun readingDao(): ReadingDao

    companion object {
        @Volatile
        private var INSTANCE: DadHealthDatabase? = null

        fun getInstance(context: Context): DadHealthDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    DadHealthDatabase::class.java,
                    "dad_health_tracker.db"
                ).build()
                INSTANCE = instance
                instance
            }
        }
    }
}
