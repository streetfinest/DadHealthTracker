# Build Without Android Studio

This version includes GitHub Actions cloud build support.

Use:

`docs/CLOUD_BUILD_GUIDE.md`

That guide shows how to upload this project to GitHub and get an APK built online.
