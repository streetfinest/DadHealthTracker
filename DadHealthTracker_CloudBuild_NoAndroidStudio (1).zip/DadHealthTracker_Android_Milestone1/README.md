# Dad Health Tracker — Android APK Project

Private offline Android app for recording blood sugar, blood pressure, pulse, notes, history, CSV reports, and backups.

## Current Milestone

**Milestone 1: Core Android Project**

Included:
- Kotlin Android project setup
- Jetpack Compose UI
- Room local database
- Dashboard
- Add Reading screen
- History screen
- CSV report export
- JSON backup export

Not included yet:
- PDF export
- Restore backup screen
- Signed release APK
- Swahili mode
- App icon polish

## Package Name

`com.streetfinest.dadhealthtracker`

## Open in Android Studio

1. Extract this ZIP.
2. Open Android Studio.
3. Choose **Open**.
4. Select this project folder.
5. Let Gradle sync.
6. Run on an Android phone/emulator.

## Build APK

Android Studio:

`Build` → `Build App Bundle(s) / APK(s)` → `Build APK(s)`

Debug APK output:

`app/build/outputs/apk/debug/`

## Important

This is source code, not a compiled APK. You still need Android Studio to build the APK.
