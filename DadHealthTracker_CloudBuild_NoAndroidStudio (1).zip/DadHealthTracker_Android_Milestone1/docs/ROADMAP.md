# Dad Health Tracker Roadmap

## Milestone 1 — Core App

Goal: working offline Android app that saves readings locally.

Features:
- Dashboard
- Add Reading
- History
- Room database
- CSV export
- JSON backup export

## Milestone 2 — Data Safety

Goal: make it reliable for long-term use.

Features:
- Restore backup from JSON
- Duplicate prevention
- Confirm-before-delete
- Last-backup reminder
- Better validation

## Milestone 3 — Reports

Goal: clinic-ready reports.

Features:
- Weekly PDF
- Monthly PDF
- Custom date range
- Share PDF to WhatsApp/Gmail/Drive

## Milestone 4 — UI Polish

Goal: elder-friendly design.

Features:
- Bigger text option
- Swahili labels
- App icon
- Better dashboard visuals

## Milestone 5 — Release APK

Goal: installable APK for family use.

Features:
- Signed release APK
- Version code/version name
- Installation guide
- Backup/restore guide
