# Cloud Build Guide — Build APK Without Android Studio

This method lets GitHub build the APK online. You do not need Android Studio installed on your computer.

## What you need

- A GitHub account
- Internet browser
- This project folder

## Step 1 — Create GitHub Account

Go to GitHub and create/sign in to your account.

## Step 2 — Create New Repository

1. Click **New repository**
2. Repository name: `DadHealthTracker`
3. Set it to **Private**
4. Click **Create repository**

## Step 3 — Upload Project Files

Open the extracted project folder and upload everything inside it to the repository.

Important:
Upload the contents of `DadHealthTracker_Android_Milestone1`, not the ZIP file itself.

The repository must show files like:

- `settings.gradle.kts`
- `build.gradle.kts`
- `app/`
- `gradle/`
- `.github/workflows/build-debug-apk.yml`

## Step 4 — Start the Build

1. Open your repository on GitHub
2. Click **Actions**
3. Click **Build Debug APK**
4. Click **Run workflow**
5. Click the green **Run workflow** button

GitHub will start building the app online.

## Step 5 — Download APK

When the build finishes:

1. Open the completed workflow run
2. Scroll to **Artifacts**
3. Download `DadHealthTracker-debug-apk`
4. Extract the downloaded ZIP
5. Inside it, find the APK file

## Step 6 — Install on Android Phone

Send the APK to the phone using:

- WhatsApp
- Telegram
- Google Drive
- USB cable

On the phone:
1. Open the APK
2. Allow installation from that source
3. Install
4. Open Dad Health Tracker

## Important

This creates a **debug APK** for testing only.

For final family distribution, we will later build a **signed release APK**.
